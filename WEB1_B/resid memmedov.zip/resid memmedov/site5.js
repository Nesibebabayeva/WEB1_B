
function al(){
    var qiy1=document.getElementById("qiy1");
    var qiy2=document.getElementById("qiy2");
    var chang=qiy1.value;
    qiy1.value=qiy2.value;
    qiy2.value=chang;
    
    console.log(qiy1);
    console.log(qiy2);
}
