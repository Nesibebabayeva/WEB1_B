var array=["menu1","menu2","menu3"];

function addmenu(){
    
    var sin=document.getElementById('sin');
    var menu='<ul>';
    for (let i = 0; i < array.length; i++) {
        menu+='<li>'+ array[i] +'</li>';
        
  }


    menu+='</ul>';
    sin.innerHTML=menu;
  
}
addmenu();
function newmenu(){
    var qiy=document.getElementById('qiy');
    array.push(qiy.value);
    qiy.value='';
    addmenu();
}
