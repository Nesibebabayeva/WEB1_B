muellim burda responsiv dizaynda herseyi siz gosteren formada edirem amma bir classa ikinci adi menimsedende deyismir yeni sadece basdaki yazdigina baxir meselen men komputerler ucun yazmisamsa o ancaq onlarda isleyir telefon ucun yazdigim clasi nezere almir telefon rejimine kecende 
amma kod siz yazan kimidir
